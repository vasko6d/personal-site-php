function [U] = maccormack(x,y,X,Y,shocks)
%Check arg number to see if we want to plot the schocks on results
    if nargin < 5
        shocks = 0;
    end
%OPTION: Animate plot with this flag
    animate = false;
%--------------------------------------------------------------------------
%PRE-PROCESSING: Settig up structures for numerical method
%--------------------------------------------------------------------------
%Declare Grid Size
    dim = size(x);
    grid_res = (dim(2)-2)/40;
    IL = 40*grid_res+2; 
    JL = 20*grid_res+2; 
    IS =  5*grid_res+1;
    dx = x(1,2)-x(1,1);
    dy_min = Y(2,IL)-Y(1,IL);
%Givens. ICs and BCs
    p1 = 10^5;
    rho1 = 1;
    M1 = 2.9;        
    gamma = 1.4;
%Some more important needed quantites for numerical implemetation. 
    c1 = sqrt(gamma*p1/rho1);
    u1 = M1*c1;
    v1 = 0;
    e1 = energy(rho1,p1,u1,v1);
    U1 = [rho1;rho1*u1;rho1*v1;e1];
    E1 = [rho1*u1;rho1*u1^2+p1;rho1*u1*v1;(e1+p1)*u1];
    F1 = [rho1*v1;rho1*u1*v1;rho1*v1^2+p1;(e1+p1)*v1];
%Make structures to hold each cells pertinent values.
    %geometry based - Area(V)m side lengths(S), normals(N)
        N = zeros(dim(1),dim(2),2,4);
        S = zeros(dim(1),dim(2),4);
        V = zeros(dim);
    %flow based - flux vectors E and F. Also U
        E = zeros(dim(1),dim(2),4);
        F = E;
        U = F;
    %Set up grid for these quantities
        for i=1:dim(2)
            for j=1:dim(1)
                [n,s,v] = cell_normals(X,Y,[j,i]);
                N(j,i,:,:) = n;
                S(j,i,:) = s;
                V(j,i) = v;
                E(j,i,:) = E1;
                F(j,i,:) = F1;
                U(j,i,:) = U1;
            end
        end
%--------------------------------------------------------------------------
%NUMERICAL METHOD: MACCORMACK
%--------------------------------------------------------------------------
    %Some variables needed for iteration
        newU = U; newU_ = U;
        t = 0; delta = 1; steps = 0;
    %set up grid for the animated plot (if so desire)
        if animate, plot_grid(x,y,X,Y,false,false);hold on; end;
        
 %-----------------MAIN TIME STEPPING LOOP---------------------------------    
    for tau=1:500%It want to manually set time steps
    %while delta >0.0004
        %Set the slave cells
            U = set_slave(U);
        %Set E and F based on this adjusted U
            [E,F,rho,u,v,p] = recalc_EF(U,E,F);
        %Need a new dt each loop. 
            u = abs(u);
            v = abs(v);
            c = (gamma*p./rho).^0.5;
            dt = min(min(1./((u(2:JL-1,2:IL-1)/dx)+...
                (v(2:JL-1,2:IL-1)/dy_min)...
                +c(2:JL-1,2:IL-1)*(1/dx^2+1/dy_min^2)^0.5)));
            t = t+dt; steps = steps + 1;
        %Declare the dotted flux vector to be iterated with
            Ep_dot = zeros(size(U)); E_dot = Ep_dot;
            Fp_dot = Ep_dot; F_dot = Ep_dot;
        %Simplify indexing using simplifications a and b
            a = 2:JL-1; b = 2:IL-1;           
    %--------PREDICTOR-----------------------------------------------------
        %Begin the loop
             for i=1:4
             %Calculate dotted flux quantities
                Ep_dot(a,b,i) = E(a,3:IL,i).*N(a,b,1,2)... 
                              + F(a,3:IL,i).*N(a,b,2,2);
                E_dot(a,b,i)  = E(a,b,i).*N(a,b,1,4)...
                              + F(a,b,i).*N(a,b,2,4);
                Fp_dot(a,b,i) = E(3:JL,b,i).*N(a,b,1,3)...
                              + F(3:JL,b,i).*N(a,b,2,3);
                F_dot(a,b,i)  = E(a,b,i).*N(a,b,1,1)...
                              + F(a,b,i).*N(a,b,2,1);  
            %Calculate the predictor
                newU_(a,b,i) = U(a,b,i) - dt./V(a,b).*...
                    (Ep_dot(a,b,i).*S(a,b,2) + E_dot(a,b,i).*S(a,b,4)...
                     + Fp_dot(a,b,i).*S(a,b,3) + F_dot(a,b,i).*S(a,b,1));
             end
        %Set the slave cells
            newU_ = set_slave(newU_);
        %Set E and F based on this adjusted U
            [E,F] = recalc_EF(newU_,E,F);
        %Declare dotted flux vectors to be used in Corrector
            Em_dot = zeros(size(U)); Fm_dot = Em_dot;            
    %--------Corrector-----------------------------------------------------
        %Begin the loop
            for i=1:4
            %Calculate dotted flux qunatities
                E_dot(a,b,i)  = E(a,b,i).*N(a,b,1,2)...
                              + F(a,b,i).*N(a,b,2,2);
                Em_dot(a,b,i) = E(a,1:IL-2,i).*N(a,b,1,4)...
                              + F(a,1:IL-2,i).*N(a,b,2,4);
                F_dot(a,b,i)  = E(a,b,i).*N(a,b,1,3)...
                              + F(a,b,i).*N(a,b,2,3);
                Fm_dot(a,b,i) = E(1:JL-2,b,i).*N(a,b,1,1)...
                              + F(1:JL-2,b,i).*N(a,b,2,1);   
           %Calculate the predictor
               newU(a,b,i) = 0.5*(U(a,b,i) + newU_(a,b,i) - dt./V(a,b).*...
                    (E_dot(a,b,i).*S(a,b,2)...
                     + Em_dot(a,b,i).*S(a,b,4)...
                     + F_dot(a,b,i).*S(a,b,3)...
                     + Fm_dot(a,b,i).*S(a,b,1)));
            end
        %Set U to the new values and we are ready to move on
            U = newU;
        %If the internal flag is set animate
            if animate,
               plot_results(x,y,X,Y,U,shocks,true);
            end
    end
    fprintf('Convergence took:\n\t %d seconds\n\t%d steps\n',t,steps);
%--------------------------------------------------------------------------
%POST-PROCESSING
%--------------------------------------------------------------------------
if ~animate
    plot_results(x,y,X,Y,U,shocks,false);
end
%--------------------------------------------------------------------------
%Auxillarily Functions
%--------------------------------------------------------------------------
    function [e] = energy(rho, p, u,v)
    gamma = 1.4;
    e = p/(gamma-1)+rho.*((u.^2+v.^2)/2);
    end
end